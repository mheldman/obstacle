
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.0.1'
version = '0.0.1'
full_version = '0.0.1'
git_revision = 'd858dda35907897bd66f1efcf20b5ec08c3be5ad'
release = True
if not release:
    version = full_version
