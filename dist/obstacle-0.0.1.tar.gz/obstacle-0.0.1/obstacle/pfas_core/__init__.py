"""pfas_core - a C++ implementation of PFAS-related routines
"""
from __future__ import absolute_import

from obstacle.pfas_core.relaxation import *
