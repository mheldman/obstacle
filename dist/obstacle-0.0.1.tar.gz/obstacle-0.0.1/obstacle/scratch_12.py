from diagnostics import elastictorsion_rsp_diagnostic, elastictorsion_pfas_diagnostic, damproblem_PN_diagnostic, radialproblem_pfas_diagnostic, radialproblem_rsp_diagnostic, radialproblem_PN_diagnostic, damproblem_pfas_diagnostic, damproblem_rsp_diagnostic, damproblem_pgs_diagnostic, unconstrproblem_pfas_diagnostic, unconstrproblem_multigrid_diagnostic, radialproblem_pgs_diagnostic
import cProfile
import matplotlib.pyplot as plt
import numpy as np

#radialproblem_pfas_diagnostic('FW', coarse_mx = 1, coarse_my = 1, min_num_levels =2, max_num_levels = 15, step = 1, smoothing_iters=2)

#radialproblem_rsp_diagnostic(coarse_mx = 1, coarse_my = 1, min_num_levels = 5, max_num_levels = 6, step = 1)

damproblem_pfas_diagnostic('FW', coarse_mx = 1, coarse_my = 2, min_num_levels = 2, max_num_levels = 15, step = 1, smoothing_iters=2)

#iterates = damproblem_rsp_diagnostic(coarse_mx = 1, coarse_my = 2, min_num_levels = 6, max_num_levels = None, step = 1)

#unconstrproblem_pfas_diagnostic('V', coarse_mx = 1, coarse_my = 1, min_num_levels = 5, max_num_levels = 10, step = 1)

#unconstrproblem_multigrid_diagnostic('W', coarse_mx = 1, coarse_my = 1, min_num_levels = 5, max_num_levels = 10, step = 1)

#radialproblem_PN_diagnostic(coarse_mx = 1, coarse_my = 1, min_num_levels = 3, max_num_levels = 10, step = 1)

#damproblem_PN_diagnostic(coarse_mx = 1, coarse_my = 2, min_num_levels = 3, max_num_levels = None, step = 1)

#radialproblem_pgs_diagnostic(coarse_mx = 1, coarse_my = 1, min_num_levels = 6, max_num_levels = None, step = 1)

#damproblem_pgs_diagnostic(coarse_mx = 1, coarse_my = 1, min_num_levels = 6, max_num_levels = None, step = 1)

#elastictorsion_pfas_diagnostic('FW', coarse_mx = 1, coarse_my = 1, min_num_levels = 2, max_num_levels = 15, step = 1, smoothing_iters=2)

#elastictorsion_rsp_diagnostic(coarse_mx = 1, coarse_my = 1, min_num_levels = 6, max_num_levels = None, step = 1)


